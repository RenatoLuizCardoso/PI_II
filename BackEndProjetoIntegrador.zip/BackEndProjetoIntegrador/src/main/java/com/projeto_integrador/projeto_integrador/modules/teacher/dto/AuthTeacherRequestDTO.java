package com.projeto_integrador.projeto_integrador.modules.teacher.dto;

public record AuthTeacherRequestDTO(String institutionalEmail, String teacherPassword) {
    
}
