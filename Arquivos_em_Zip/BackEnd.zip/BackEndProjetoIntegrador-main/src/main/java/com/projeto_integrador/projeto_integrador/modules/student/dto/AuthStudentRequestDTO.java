package com.projeto_integrador.projeto_integrador.modules.student.dto;


public record AuthStudentRequestDTO(String institutionalEmail, String studentPassword) {
    
}
