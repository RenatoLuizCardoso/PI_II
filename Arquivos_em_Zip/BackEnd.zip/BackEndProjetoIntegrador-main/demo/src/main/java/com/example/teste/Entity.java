package com.example.teste;


public class Entity {
    
}
