
export interface Cursos {
  id: number;
  nameCourse: string;
  semester: string;
  period: string;
  disciplineName: string; 
}
