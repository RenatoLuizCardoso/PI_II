import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar-prof',
  templateUrl: './navbar-prof.component.html',
  styleUrl: './navbar-prof.component.css'
})
export class NavbarProfComponent {

}
