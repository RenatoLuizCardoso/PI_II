
export interface Professores {
  id: number;
  emailI: string;
  emailp: string;
  nameCourse: string;
  name: string;
  tel: number;
  passwd: string;
}
