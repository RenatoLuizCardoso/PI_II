
export interface Salas {
  resources: string;
  capacity: number;
  floor: string;
  type: string;
  availability: boolean;
}
