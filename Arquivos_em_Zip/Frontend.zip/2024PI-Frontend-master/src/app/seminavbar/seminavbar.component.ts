import { Component } from '@angular/core';

@Component({
  selector: 'app-seminavbar',
  templateUrl: './seminavbar.component.html',
  styleUrl: './seminavbar.component.css'
})
export class SeminavbarComponent {

}
