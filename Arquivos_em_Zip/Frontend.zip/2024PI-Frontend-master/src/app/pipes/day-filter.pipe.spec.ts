import { DayFilterPipe } from './day-filter.pipe';

describe('DayFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DayFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
