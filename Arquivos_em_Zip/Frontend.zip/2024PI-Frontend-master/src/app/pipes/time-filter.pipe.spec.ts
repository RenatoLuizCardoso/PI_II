import { TimeFilterPipe } from './time-filter.pipe';

describe('TimeFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TimeFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
